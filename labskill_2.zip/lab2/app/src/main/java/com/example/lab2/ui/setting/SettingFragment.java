package com.example.lab2.ui.setting;

import static android.app.Activity.RESULT_OK;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.example.lab2.R;
import com.example.lab2.BetterActivityResult;

public class SettingFragment extends Fragment {
    private static final int CAMERA_PERM_CODE =101;
    protected final BetterActivityResult<Intent, ActivityResult> activityLauncher = BetterActivityResult.registerActivityForResult(this);

    ImageView profileVImage;
    ImageView addVImage;
    Button b;

    SharedPreferences pref;
    private Bitmap pImageBitmap;
    String currentPhotoPath;

    private ActivityResultLauncher<String> mPermissionResult = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            new ActivityResultCallback<Boolean>() {
                @Override
                public void onActivityResult(Boolean result) {
                    if(result) {
                        Toast.makeText(getActivity(), "camera permission granted", Toast.LENGTH_LONG).show();
                        doOperationTakePhoto();
                    } else {
                        Toast.makeText(getActivity(), "camera permission denied", Toast.LENGTH_LONG).show();
                    }
                }
            });



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_setting, container, false);
        pref = this.getActivity().getSharedPreferences("user_details", Context.MODE_PRIVATE);

        profileVImage = (ImageView) root.findViewById(R.id.img_profile);
        addVImage = (ImageView) root.findViewById(R.id.img_plus);
        setPhotoProfile();

        addVImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPermissionResult.launch(Manifest.permission.CAMERA);

            }
        });
        return root;
    }

    public void doOperationTakePhoto(){
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        activityLauncher.launch(takePictureIntent, result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Bundle bundle = result.getData().getExtras();
                Bitmap bitmap = (Bitmap) bundle.get("data");
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

                File destination = new File(getActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                        "profilephoto.jpg");
                FileOutputStream fo;
                try {
                    destination.createNewFile();
                    fo = new FileOutputStream(destination);
                    fo.write(bytes.toByteArray());
                    fo.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Toast.makeText(getActivity(), destination.toString(), Toast.LENGTH_LONG).show();
                Log.i("mytag", destination.toString());

                currentPhotoPath = destination.toString();
                SharedPreferences.Editor editor = pref.edit();
                editor.clear();
                editor.putString("profilePhotoPath", currentPhotoPath);
                editor.commit();
                setPhotoProfile();
            }
        });
    }

    public void setPhotoProfile(){
        if(pref.contains("profilePhotoPath")) {
            currentPhotoPath = pref.getString("profilePhotoPath", "defaultPath");

            File imgFile = new File(currentPhotoPath);
            if (imgFile.exists()) {
                Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                ImageView myImage = getActivity().findViewById(R.id.imageView);
                myImage.setImageBitmap(myBitmap);
                profileVImage.setImageBitmap(myBitmap);
                Log.i("mytag", "success");
            }
        }
        else{
            profileVImage.setImageResource(R.drawable.baseline_account_circle_black_48);
            ImageView myImage = getActivity().findViewById(R.id.imageView);
            myImage.setImageResource(R.drawable.baseline_account_circle_black_48);
        }
    }

}